export const donation = {
  // Usa tu correo de PayPal como destinatario (ya configurado con tu email)
  paypalBusinessEmail: "jaimerivasgranada@gmail.com", // <-- actualizado

  // Si algún día quieres usar el botón oficial, puedes poner aquí tu hosted_button_id
  paypalHostedButtonId: "",

  // O si prefieres PayPal.Me, pon tu usuario aquí (opcional)
  paypalMeUsername: "",

  // Cantidad por defecto para PayPal.Me (opcional)
  defaultAmount: "",

  // Moneda a usar en el enlace de donación por email
  currency: "EUR",
}
